# Project Game - DAW


## Miembros del Projecto


*   **Juan Elias**
*   **Juan Carlos**
*   **Christian Yepes**


## Objetivos del Projecto

* Crear un videojuego como presentacion ante un projecto del modulo de Grado Superior: **Desarrollo de Apliaci�nes Wen (DAW)**.
* Aprender como hacer, gestionar y mantener una aplicaci�n completa.






