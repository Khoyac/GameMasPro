/*
 * 
 */
package modelo;

// TODO: Auto-generated Javadoc
/**
 * The Interface Acciones.
 */
public interface Acciones {

	/**
	 * Mover.
	 *
	 * @return the int
	 */
	public int mover();

	/**
	 * Atacar.
	 *
	 * @return the int
	 */
	public int atacar();

	/**
	 * Defender.
	 *
	 * @return the int
	 */
	public int defender();

	/**
	 * Lanzar hechizo.
	 *
	 * @return the int
	 */
	public int lanzarHechizo();

}
