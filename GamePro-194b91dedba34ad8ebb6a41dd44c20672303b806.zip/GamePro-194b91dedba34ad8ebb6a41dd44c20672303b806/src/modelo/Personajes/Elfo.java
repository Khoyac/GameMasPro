/*
 * 
 */
package modelo.Personajes;

/**
 * The Class Elfo.
 */
public abstract class Elfo extends Raza {

}
