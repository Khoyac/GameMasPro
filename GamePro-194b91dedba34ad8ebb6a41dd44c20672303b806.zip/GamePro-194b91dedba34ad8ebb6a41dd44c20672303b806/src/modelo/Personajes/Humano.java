/*
 * 
 */
package modelo.Personajes;

/**
 * The Class Humano.
 */
public abstract class Humano extends Raza {

	// Atributos

	// Constructores

	// Get && Set

	// Metodos

}
