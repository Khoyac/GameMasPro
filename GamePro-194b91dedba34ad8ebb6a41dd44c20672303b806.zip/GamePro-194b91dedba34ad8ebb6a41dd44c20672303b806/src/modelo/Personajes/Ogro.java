/*
 * 
 */
package modelo.Personajes;

/**
 * The Class Ogro.
 */
public abstract class Ogro extends Raza {

}
