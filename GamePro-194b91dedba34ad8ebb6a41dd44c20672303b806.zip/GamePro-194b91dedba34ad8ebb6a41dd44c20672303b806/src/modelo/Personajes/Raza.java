/*
 * 
 */
package modelo.Personajes;

/**
 * The Class Raza.
 */
public abstract class Raza extends Personaje {

}
