/*
 * 
 */
package modelo.Personajes;

// TODO: Auto-generated Javadoc
/**
 * The Class Tanke.
 */
public class Tanke extends Ogro {

	/**
	 * Mover.
	 *
	 * @return the int
	 */
	@Override
	public int mover() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Atacar.
	 *
	 * @return the int
	 */
	@Override
	public int atacar() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Defender.
	 *
	 * @return the int
	 */
	@Override
	public int defender() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Lanzar hechizo.
	 *
	 * @return the int
	 */
	@Override
	public int lanzarHechizo() {
		// TODO Auto-generated method stub
		return 0;
	}

}
